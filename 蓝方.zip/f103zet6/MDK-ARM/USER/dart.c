
#include "dart.h"

void launch(int speed)   //use step motor & frc wheel to launch
{        //
	        	HAL_GPIO_WritePin(GPIOA,GPIO_PIN_5,GPIO_PIN_RESET);//��ת
	     
					
					//left&right frction wheel speed 100max 50zero
				 __HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_1,speed);  //lb
	       __HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_2,speed);  //lf
	       __HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_3,speed);  //rf
				 __HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_4,speed);  //rb
	     	//stepmotor PWM
	       HAL_Delay(3000);
		     __HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_1,250);
		     HAL_Delay(1600);
				//shutdown frction wheel&stepmotor
				
	
		     HAL_GPIO_WritePin(GPIOA,GPIO_PIN_5,GPIO_PIN_SET);//��ת��λ
				 HAL_Delay(1600);
				 __HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_1,0);//ֹͣ
	
	       __HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_1,0);
	       __HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_2,0);
	       __HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_3,0); 
				 __HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_4,0);
}

void catchdart(int num)
{

	//$DGT:0-10,1! ���ö��� G0000~G0010 �� 1 �Σ� ��Ϊ0 �������ѭ��ִ��ǰ���Ƕ����Ѵ洢
	  if(num==0)
		{			
			uint8_t action_cmd[] ="{G0001#000P1700T1500!#001P2167T1500!#002P2500T1500!#003P2000T1500!#004P1500T1500!#005P1500T1500!}";
       HAL_UART_Transmit(&huart4, action_cmd, sizeof(action_cmd), 1000); 
	   
		}
		if(num==1)
		{
			uint8_t action_cmd[] = "$DGT:2-11,1!"; // ������1����ָ��
			HAL_UART_Transmit(&huart4, action_cmd, sizeof(action_cmd), 1000); 
			 HAL_Delay(17000);
			
		}
  
	
}

