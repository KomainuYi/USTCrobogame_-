#ifndef __DART_H
#define	__DART_H

#include "main.h"
#include "gpio.h"
#include "tim.h"
#include "usart.h"

void catchdart(int num);
void launch(int speed);  				  


#endif 
