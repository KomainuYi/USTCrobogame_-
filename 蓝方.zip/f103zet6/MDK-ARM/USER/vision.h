#ifndef __VISION_H
#define	__VISION_H

#include "main.h"

#include "usart.h"





void vision_target(void);				  


#endif 
