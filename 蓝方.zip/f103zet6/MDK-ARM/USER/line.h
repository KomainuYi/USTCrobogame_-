/*--------------------------------------------------------------*/
//��ֹ�ظ�����
#ifndef	__LINE_H__
#define __LINE_H__
/*--------------------------------------------------------------*/
#include "motor.h"
#include "sensor.h"
#include "main.h"
#include "dart.h"
void track_turnright(int forward,int right,int delay);
void track_turnleft(int forward,int right,int delay);

void track_zhixian1(void);
void track_zhixian2(void);
void track_straightline(void);
void track_dart(void);

void statezero(void);
void stateone(void);
void statetwo(void);
void statetwo1(void);

void statethree(void);
void open(void);
#endif

